<?php
include "koneksi.php";
include "header.php";

// ambil semua data atribut dari tabel node
$select_atribut = mysqli_query($koneksi, "select * from node");

$semua_data = [];

while($data = mysqli_fetch_array($select_atribut)) {
    // tiap record dari atribut di simpan ke variabel semua data
    // hal ini akan digunakan untuk sistem pakar
    $semua_data[$data['grup']][$data['atribut']] = [
        'c1' => $data['c1'],
        'c2' => $data['c2'],
    ];
}
?>

<h1>Pakar</h1>

<form method="post">
    <div class="form-group row">
        <label class="col-form-label col-sm-4">Usia Pasien?</label>
        <div class="col-sm-3">
            <select name="usia" class="form-control">
                <?php
                foreach($semua_data['Usia'] as $key => $val):
                ?>
                    <option value="<?= $key ?>" <?= isset($_POST['usia']) && $_POST['usia'] == $key ? 'selected':''?>><?= $key ?></option>
                <?php
                endforeach;
                ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-form-label col-sm-4">Memiliki Gejala Miokard?</label>
        <div class="col-sm-3">
            <select name="gejala_miokard" class="form-control">
                <?php
                foreach($semua_data['Gejala Miokard'] as $key => $val):
                ?>
                    <option value="<?= $key ?>" <?= isset($_POST['gejala_miokard']) && $_POST['gejala_miokard'] == $key ? 'selected':''?>><?= $key ?></option>
                <?php
                endforeach;
                ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-form-label col-sm-4">Apakah pasien Merokok?</label>
        <div class="col-sm-3">
            <select name="merokok" class="form-control">
                <?php
                foreach($semua_data['Merokok'] as $key => $val):
                ?>
                    <option value="<?= $key ?>" <?= isset($_POST['merokok']) && $_POST['merokok'] == $key ? 'selected':''?>><?= $key ?></option>
                <?php
                endforeach;
                ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-form-label col-sm-4">Memiliki penyakit Diabetes?</label>
        <div class="col-sm-3">
            <select name="diabetes" class="form-control">
                <?php
                foreach($semua_data['Diabetes'] as $key => $val):
                ?>
                    <option value="<?= $key ?>" <?= isset($_POST['diabetes']) && $_POST['diabetes'] == $key ? 'selected':''?>><?= $key ?></option>
                <?php
                endforeach;
                ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-form-label col-sm-4">Memiliki penyakit Darah Tinggi?</label>
        <div class="col-sm-3">
            <select name="darah_tinggi" class="form-control">
                <?php
                foreach($semua_data['Darah Tinggi'] as $key => $val):
                ?>
                    <option value="<?= $key ?>" <?= isset($_POST['darah_tinggi']) && $_POST['darah_tinggi'] == $key ? 'selected':''?>><?= $key ?></option>
                <?php
                endforeach;
                ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-form-label col-sm-4">Memiliki Kolesterol Tinggi?</label>
        <div class="col-sm-3">
            <select name="kolesterol" class="form-control">
                <?php
                foreach($semua_data['Kolesterol'] as $key => $val):
                ?>
                    <option value="<?= $key ?>" <?= isset($_POST['kolesterol']) && $_POST['kolesterol'] == $key ? 'selected':''?>><?= $key ?></option>
                <?php
                endforeach;
                ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-form-label col-sm-4">Memiliki Penyakit Angina?</label>
        <div class="col-sm-3">
            <select name="angina" class="form-control">
                <?php
                foreach($semua_data['Angina'] as $key => $val):
                ?>
                    <option value="<?= $key ?>" <?= isset($_POST['angina']) && $_POST['angina'] == $key ? 'selected':''?>><?= $key ?></option>
                <?php
                endforeach;
                ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-form-label col-sm-4">Memiliki Penyakit Stroke?</label>
        <div class="col-sm-3">
            <select name="stroke" class="form-control">
                <?php
                foreach($semua_data['Stroke'] as $key => $val):
                ?>
                    <option value="<?= $key ?>" <?= isset($_POST['stroke']) && $_POST['stroke'] == $key ? 'selected':''?>><?= $key ?></option>
                <?php
                endforeach;
                ?>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-4"></div>
        <div class="col-sm-3">
            <button type="submit" name="submit" class="btn btn-primary">Klasifikasi</button>
        </div>
    </div>
</form>

<?php
if (isset($_POST['submit'])) {
    // hitung total c1 dari tiap atribut yang di kirim dari form
    $c1 = $semua_data['Usia'][$_POST['usia']]['c1'] *
        $semua_data['Gejala Miokard'][$_POST['gejala_miokard']]['c1'] *
        $semua_data['Merokok'][$_POST['merokok']]['c1'] *
        $semua_data['Diabetes'][$_POST['diabetes']]['c1'] *
        $semua_data['Darah Tinggi'][$_POST['darah_tinggi']]['c1'] *
        $semua_data['Kolesterol'][$_POST['kolesterol']]['c1'] *
        $semua_data['Angina'][$_POST['angina']]['c1'] *
        $semua_data['Stroke'][$_POST['stroke']]['c1'];

    // hitung total c2 dari tiap atribut yang di kirim dari form
    $c2 = $semua_data['Usia'][$_POST['usia']]['c2'] *
        $semua_data['Gejala Miokard'][$_POST['gejala_miokard']]['c2'] *
        $semua_data['Merokok'][$_POST['merokok']]['c2'] *
        $semua_data['Diabetes'][$_POST['diabetes']]['c2'] *
        $semua_data['Darah Tinggi'][$_POST['darah_tinggi']]['c2'] *
        $semua_data['Kolesterol'][$_POST['kolesterol']]['c2'] *
        $semua_data['Angina'][$_POST['angina']]['c2'] *
        $semua_data['Stroke'][$_POST['stroke']]['c2'];

    // perbandingan dari c1 dan c2 untuk di klasifikasikan
    if ($c1 > $c2) {
        echo "<h1 class='text-primary'><small>Hasil Klasifikasi:</small><br><b>Hidup</b></h1>";
    } else {
        echo "<h1 class='text-danger'><small>Hasil Klasifikasi:</small><br><b>Meninggal</b></h1>";
    }
}